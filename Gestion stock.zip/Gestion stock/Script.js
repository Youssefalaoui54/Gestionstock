<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>إدارة مخزون PSAD MAROC</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <header>
    <h1>إدارة مخزون PSAD MAROC</h1>
  </header>
  <main>
    <section id="inventory-form">
      <h2>إضافة منتج جديد</h2>
      <form id="add-product-form">
        <label for="product-name">اسم المنتج:</label>
        <input type="text" id="product-name" required>
        
        <label for="product-quantity">الكمية:</label>
        <input type="number" id="product-quantity" required>
        
        <label for="product-category">الفئة:</label>
        <select id="product-category" required>
          <option value="أجهزة CPAP">أجهزة CPAP</option>
          <option value="ماسكات الأكسجين">ماسكات الأكسجين</option>
          <option value="فلاتر">فلاتر</option>
          <option value="أدوات أخرى">أدوات أخرى</option>
        </select>
        
        <button type="submit">إضافة</button>
      </form>
    </section>
    
    <section id="inventory-list">
      <h2>قائمة المنتجات</h2>
      <table>
        <thead>
          <tr>
            <th>اسم المنتج</th>
            <th>الكمية</th>
            <th>الفئة</th>
            <th>إجراءات</th>
          </tr>
        </thead>
        <tbody id="product-list">
          <!-- المنتجات ستضاف هنا ديناميكيًا -->
        </tbody>
      </table>
    </section>
  </main>
  <script src="script.js"></script>
</body>
</html><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>إدارة مخزون PSAD MAROC</title>
  <link rel="stylesheet" href="styles.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
  <header class="bg-primary text-white text-center py-3">
    <h1>إدارة مخزون PSAD MAROC</h1>
  </header>
  
  <main class="container my-4">
    <section id="inventory-form" class="mb-5">
      <h2 class="text-primary">إضافة منتج جديد</h2>
      <form id="add-product-form" class="row g-3">
        <div class="col-md-4">
          <label for="product-name" class="form-label">اسم المنتج:</label>
          <input type="text" id="product-name" class="form-control" required>
        </div>
        <div class="col-md-4">
          <label for="product-quantity" class="form-label">الكمية:</label>
          <input type="number" id="product-quantity" class="form-control" required>
        </div>
        <div class="col-md-4">
          <label for="product-category" class="form-label">الفئة:</label>
          <select id="product-category" class="form-select" required>
            <option value="أجهزة CPAP">أجهزة CPAP</option>
            <option value="ماسكات الأكسجين">ماسكات الأكسجين</option>
            <option value="فلاتر">فلاتر</option>
            <option value="أدوات أخرى">أدوات أخرى</option>
          </select>
        </div>
        <div class="col-12">
          <button type="submit" class="btn btn-primary">إضافة المنتج</button>
        </div>
      </form>
    </section>
    
    <section id="inventory-list">
      <h2 class="text-primary">قائمة المنتجات</h2>
      <table class="table table-striped table-hover">
        <thead class="table-dark">
          <tr>
            <th>اسم المنتج</th>
            <th>الكمية</th>
            <th>الفئة</th>
            <th>إجراءات</th>
          </tr>
        </thead>
        <tbody id="product-list">
          <!-- المنتجات ستضاف هنا ديناميكيًا -->
        </tbody>
      </table>
    </section>
  </main>

  <footer class="text-center py-3 bg-light">
    <p>© 2024 PSAD MAROC - جميع الحقوق محفوظة</p>
  </footer>
  
  <script src="script.js"></script>
</body>
</html>/* styles.css */
body {
  font-family: 'Cairo', sans-serif;
  background-color: #f8f9fa;
  margin: 0;
  padding: 0;
}

h1, h2 {
  font-weight: bold;
}

footer {
  margin-top: 20px;
}

button {
  transition: background-color 0.3s ease;
}

button:hover {
  background-color: #004085;
}<header class="bg-primary text-white text-center py-3">
  <div class="container d-flex align-items-center justify-content-center">
    <img src="LOGO PSAD MAROC--.jpg" alt="شعار PSAD MAROC" class="me-3" style="width: 100px; height: auto;">
    <h1>إدارة مخزون PSAD MAROC</h1>
  </div>
</header><header class="bg-primary text-white text-center py-3">
  <div class="container d-flex align-items-center justify-content-between">
    <div class="d-flex align-items-center">
      <img src="LOGO PSAD MAROC--.jpg" alt="شعار PSAD MAROC" class="me-3" style="width: 100px; height: auto;">
      <h1 id="app-title">إدارة مخزون PSAD MAROC</h1>
    </div>
    <div>
      <label for="language-select" class="form-label text-white">اللغة:</label>
      <select id="language-select" class="form-select d-inline-block" style="width: auto;">
        <option value="ar">العربية</option>
        <option value="fr">Français</option>
        <option value="en">English</option>
      </select>
    </div>
  </div>
</header>document.getElementById("language-select").addEventListener("change", function () {
  const selectedLanguage = this.value;
  changeLanguage(selectedLanguage);
});

// تعيين اللغة الافتراضية
document.addEventListener("DOMContentLoaded", () => {
  changeLanguage("ar"); // اللغة الافتراضية: العربية
});<header class="bg-primary text-white text-center py-3">
  <div class="container d-flex align-items-center justify-content-between">
    <div class="d-flex align-items-center">
      <img src="LOGO PSAD MAROC--.jpg" alt="شعار PSAD MAROC" class="me-3" style="width: 100px; height: auto;">
      <h1 id="app-title">إدارة مخزون PSAD MAROC</h1>
    </div>
    <div>
      <label for="language-select" class="form-label text-white">اللغة:</label>
      <select id="language-select" class="form-select d-inline-block" style="width: auto;">
        <option value="ar">العربية</option>
        <option value="fr">Français</option>
        <option value="en">English</option>
      </select>
    </div>
  </div>
</header>

<main class="container my-4">
  <section id="inventory-form" class="mb-5">
    <h2 class="text-primary">إضافة منتج جديد</h2>
    <form id="add-product-form" class="row g-3">
      <div class="col-md-4">
        <label for="product-name" class="form-label">اسم المنتج:</label>
        <input type="text" id="product-name" class="form-control" required>
      </div>
      <div class="col-md-4">
        <label for="product-quantity" class="form-label">الكمية:</label>
        <input type="number" id="product-quantity" class="form-control" required>
      </div>
      <div class="col-md-4">
        <label for="product-category" class="form-label">الفئة:</label>
        <select id="product-category" class="form-select" required>
          <option value="Oxymètres">Oxymètres</option>
          <option value="Oxygène">Oxygène</option>
          <option value="VNI">VNI</option>
          <option value="CPAP">CPAP</option>
        </select>
      </div>
      <div class="col-12">
        <button type="submit" class="btn btn-primary">إضافة المنتج</button>
      </div>
    </form>
  </section>

  <section id="inventory-list">
    <h2 class="text-primary">قائمة المنتجات</h2>
    <table class="table table-striped table-hover">
      <thead class="table-dark">
        <tr>
          <th>اسم المنتج</th>
          <th>الكمية</th>
          <th>الفئة</th>
          <th>إجراءات</th>
        </tr>
      </thead>
      <tbody id="product-list">
        <!-- المنتجات ستضاف هنا ديناميكيًا -->
      </tbody>
    </table>
  </section>
</main>

<footer class="text-center py-3 bg-light">
  <p>© 2024 PSAD MAROC - جميع الحقوق محفوظة</p>
</footer>// script.js

document.getElementById("add-product-form").addEventListener("submit", function (event) {
  event.preventDefault();

  const productName = document.getElementById("product-name").value;
  const productQuantity = document.getElementById("product-quantity").value;
  const productCategory = document.getElementById("product-category").value;

  const product = { name: productName, quantity: productQuantity, category: productCategory };

  addProductToTable(product);

  this.reset();
});

// إضافة المنتج إلى الجدول
function addProductToTable(product) {
  const table = document.getElementById("product-list");
  const row = document.createElement("tr");

  row.innerHTML = `
    <td>${product.name}</td>
    <td>${product.quantity}</td>
    <td>${product.category}</td>
    <td>
      <button class="btn btn-danger btn-sm" onclick="deleteProduct(this)">حذف</button>
    </td>
  `;

  table.appendChild(row);
}

// حذف المنتج
function deleteProduct(button) {
  button.parentElement.parentElement.remove();
}<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>إدارة مخزون PSAD MAROC</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <header class="bg-primary text-white py-3">
    <div class="container d-flex align-items-center justify-content-between">
      <div class="d-flex align-items-center">
        <img src="LOGO PSAD MAROC--.jpg" alt="شعار PSAD MAROC" class="me-3" style="width: 100px; height: auto;">
        <h1 id="app-title" class="mb-0">إدارة مخزون PSAD MAROC</h1>
      </div>
      <div>
        <select id="language-select" class="form-select d-inline-block" style="width: auto;">
          <option value="ar">العربية</option>
          <option value="fr">Français</option>
          <option value="en">English</option>
        </select>
      </div>
    </div>
  </header>

  <main class="container my-4">
    <!-- لوحة التحكم -->
    <section id="dashboard" class="mb-5">
      <h2 class="text-primary">لوحة التحكم</h2>
      <div class="row text-center">
        <div class="col-md-6">
          <div class="card bg-info text-white">
            <div class="card-body">
              <h3 id="total-products">0</h3>
              <p>إجمالي المنتجات</p>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="card bg-success text-white">
            <div class="card-body">
              <h3 id="total-quantity">0</h3>
              <p>إجمالي الكميات</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- إضافة منتج جديد -->
    <section id="inventory-form" class="mb-5">
      <h2 class="text-primary">إدارة الدخول والخروج</h2>
      <form id="product-transaction-form" class="row g-3">
        <div class="col-md-4">
          <label for="product-name" class="form-label">اسم المنتج:</label>
          <select id="product-name" class="form-select" required>
            <option value="Oxymètre">Oxymètre</option>
            <option value="Oxygène">Oxygène</option>
            <option value="VNI">VNI</option>
            <option value="CPAP">CPAP</option>
          </select>
        </div>
        <div class="col-md-4">
          <label for="product-quantity" class="form-label">الكمية:</label>
          <input type="number" id="product-quantity" class="form-control" required>
        </div>
        <div class="col-md-4">
          <label for="transaction-type" class="form-label">نوع العملية:</label>
          <select id="transaction-type" class="form-select" required>
            <option value="in">دخول</option>
            <option value="out">خروج</option>
          </select>
        </div>
        <div class="col-12">
          <button type="submit" class="btn btn-primary">تسجيل العملية</button>
        </div>
      </form>
    </section>

    <!-- قائمة المنتجات -->
    <section id="inventory-list">
      <h2 class="text-primary">قائمة المنتجات</h2>
      <table class="table table-bordered table-striped table-hover">
        <thead class="table-dark">
          <tr>
            <th>اسم المنتج</th>
            <th>الكمية الحالية</th>
          </tr>
        </thead>
        <tbody id="product-list">
          <!-- المنتجات ستضاف هنا ديناميكيًا -->
        </tbody>
      </table>
    </section>
  </main>

  <footer class="text-center py-3 bg-light">
    <p>© 2024 PSAD MAROC - جميع الحقوق محفوظة</p>
  </footer>

  <script src="script.js"></script>
</body>
</html>// script.js

document.getElementById("add-product-form").addEventListener("submit", function (event) {
  event.preventDefault();

  const productName = document.getElementById("product-name").value;
  const productQuantity = document.getElementById("product-quantity").value;
  const productCategory = document.getElementById("product-category").value;

  const product = { name: productName, quantity: productQuantity, category: productCategory };

  addProductToTable(product);

  this.reset();
});

// إضافة المنتج إلى الجدول
function addProductToTable(product) {
  const table = document.getElementById("product-list");
  const row = document.createElement("tr");

  row.innerHTML = `
    <td>${product.name}</td>
    <td>${product.quantity}</td>
    <td>${product.category}</td>
    <td>
      <button class="btn btn-danger btn-sm" onclick="deleteProduct(this)">حذف</button>
    </td>
  `;

  table.appendChild(row);
}

// حذف المنتج
function deleteProduct(button) {
  button.parentElement.parentElement.remove();
}<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>إدارة مخزون PSAD MAROC</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <!-- تسجيل الدخول -->
  <div id="login-modal" class="modal show" tabindex="-1" style="display: block; background: rgba(0, 0, 0, 0.5);">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">تسجيل الدخول</h5>
        </div>
        <div class="modal-body">
          <form id="login-form">
            <div class="mb-3">
              <label for="username" class="form-label">اسم المستخدم:</label>
              <input type="text" id="username" class="form-control" required>
            </div>
            <div class="mb-3">
              <label for="password" class="form-label">كلمة المرور:</label>
              <input type="password" id="password" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">تسجيل الدخول</button>
          </form>
        </div>
      </div>
    </div>
  </div>

  <!-- محتوى التطبيق -->
  <header class="bg-primary text-white py-3">
    <div class="container d-flex align-items-center justify-content-between">
      <h1 id="app-title" class="mb-0">إدارة مخزون PSAD MAROC</h1>
      <span id="current-user" class="text-light"></span>
    </div>
  </header>

  <main class="container my-4" id="main-content" style="display: none;">
    <!-- إضافة منتج جديد -->
    <section id="inventory-form" class="mb-5">
      <h2 class="text-primary">إدارة المنتجات</h2>
      <form id="product-transaction-form" class="row g-3">
        <div class="col-md-3">
          <label for="product-name" class="form-label">اسم المنتج:</label>
          <select id="product-name" class="form-select" required>
            <option value="Oxymètre">Oxymètre</option>
            <option value="Oxygène">Oxygène</option>
            <option value="VNI">VNI</option>
            <option value="CPAP">CPAP</option>
          </select>
        </div>
        <div class="col-md-2">
          <label for="product-quantity" class="form-label">الكمية:</label>
          <input type="number" id="product-quantity" class="form-control" required>
        </div>
        <div class="col-md-2">
          <label for="transaction-type" class="form-label">نوع العملية:</label>
          <select id="transaction-type" class="form-select" required>
            <option value="in">دخول</option>
            <option value="out">خروج</option>
          </select>
        </div>
        <div class="col-md-2">
          <label for="operation-type" class="form-label">نوع الإجراء:</label>
          <select id="operation-type" class="form-select" required>
            <option value="rent">كراء</option>
            <option value="buy">شراء</option>
          </select>
        </div>
        <div class="col-md-3">
          <button type="submit" class="btn btn-primary mt-4">تسجيل العملية</button>
        </div>
      </form>
    </section>

    <!-- قائمة العمليات -->
    <section id="inventory-list">
      <h2 class="text-primary">سجل العمليات</h2>
      <table class="table table-bordered table-striped">
        <thead class="table-dark">
          <tr>
            <th>اسم المنتج</th>
            <th>الكمية</th>
            <th>نوع العملية</th>
            <th>الإجراء</th>
            <th>المستخدم</th>
          </tr>
        </thead>
        <tbody id="product-list">
          <!-- العمليات ستضاف هنا -->
        </tbody>
      </table>
    </section>
  </main>

  <script src="script.js"></script>
</body>
</html>// script.js

let currentUser = null;

// بيانات المستخدمين
const users = {
  admin: { password: "1234" },
  user1: { password: "5678" }
};

// بيانات المخزون
const inventory = {
  Oxymètre: 0,
  Oxygène: 0,
  VNI: 0,
  CPAP: 0
};

// تسجيل الدخول
document.getElementById("login-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;

  if (users[username] && users[username].password === password) {
    currentUser = username;
    document.getElementById("current-user").textContent = `مرحبًا، ${currentUser}`;
    document.getElementById("login-modal").style.display = "none";
    document.getElementById("main-content").style.display = "block";
  } else {
    alert("اسم المستخدم أو كلمة المرور غير صحيحة.");
  }
});

// تسجيل العملية
document.getElementById("product-transaction-form").addEventListener("submit", (event) => {
  event.preventDefault();

  const productName = document.getElementById("product-name").value;
  const productQuantity = parseInt(document.getElementById("product-quantity").value);
  const transactionType = document.getElementById("transaction-type").value;
  const operationType = document.getElementById("operation-type").value;

  if (transactionType === "in") {
    inventory[productName] += productQuantity;
  } else if (transactionType === "out") {
    inventory[productName] -= productQuantity;
    if (inventory[productName] < 0) inventory[productName] = 0;
  }

  addTransactionToTable(productName, productQuantity, transactionType, operationType);
});

// إضافة العملية للجدول
function addTransactionToTable(name, quantity, transaction, operation) {
  const table = document.getElementById("product-list");
  const row = document.createElement("tr");

  row.innerHTML = `
    <td>${name}</td>
    <td>${quantity}</td>
    <td>${transaction === "in" ? "دخول" : "خروج"}</td>
    <td>${operation === "rent" ? "كراء" : "شراء"}</td>
    <td>${currentUser}</td>
  `;

  table.appendChild(row);
}